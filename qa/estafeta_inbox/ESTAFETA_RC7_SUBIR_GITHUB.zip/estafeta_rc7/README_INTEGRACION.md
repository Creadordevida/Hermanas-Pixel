# ESTAFETA RC7 — Recursos candidatos, NO aprobados visualmente

## Incluye
- `source_masters/`: cuatro ilustraciones de partida, estilo SNES (arte conceptual de Estafeta, sin autenticidad topográfica certificada).
- `assets/images/estafeta_rc7/`: 39 WebP opacos de 960 × 390 píxeles, preparados para desplazamiento físico 1:1.
- `tools/build_estafeta_rc7.py`: reconstruye los 39 recursos desde los maestros.
- `manifest.json`: procedencia de los fragmentos y hashes SHA-256.
- `contact_first_ten.jpg`: control visual de los primeros diez módulos (NO es una captura Flutter).

## Integración en GitHub
Código subido a la rama `work/revision-visual-20261028-continuidad`:
- commit `9096875`: `lib/main.dart`, cargador y renderizador protegidos por `TWC_ESTAFETA_RC7_ART`.
- commit `b6e29f6`: `test/estafeta_rc7_contract_test.dart`.

FALTA SUBIR los 39 WebP. No habilitar el flag hasta subirlos, añadir en `pubspec.yaml`:

    - assets/images/estafeta_rc7/

Con los WebP incorporados, ejecutar pruebas Dart y Flutter con `--dart-define=TWC_ESTAFETA_RC7_ART=true`. El test contractual de puerta de seguridad prevé flag falso; al activarlo ha de revisarse la aserción correspondiente. Después inspeccionar capturas auténticas de `StagePainter` a 16:9, 19.5:9 y 20:9.

## Observaciones honestas
Las uniones entre fragmentos tienen diferencias visibles de cubierta y algunas fachadas cortadas: NO están aprobadas artísticamente. Los cuatro maestros ilustran arquitectura navarra plausible, pero NO documentan edificio por edificio la Calle Estafeta auténtica. Estos recursos son un avance de implementación y no permiten cerrar la orden con el estándar del colegio. La presencia de las 39 piezas no equivale a aprobación de calidad ni a prueba Android.

No se ha generado APK ni fusionado PR #5.
