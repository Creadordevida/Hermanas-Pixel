#!/usr/bin/env python3
"""Build continuous facade world from approved-style SOURCE pixels.
Facade seams occur at hand-auditable architectural boundaries; tile cuts
occur only after building the continuous world, so adjacent tiles share pixels.
This is still a repeated-source candidate, NOT a real-geography reconstruction.
"""
from PIL import Image
from pathlib import Path
from collections import Counter
import hashlib, json, random
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'assets/images/estafeta_rc7'
OUT.mkdir(parents=True,exist_ok=True)
TILES, TW, H = 39,960,390
# Approximate facade boundary positions identified from the four source plates.
# Only real source pixels are used. Boundaries should be artist-reviewed.
BOUNDARIES=[
 [0,300,540,800,1110,1390,1640,1910,2172],
 [0,290,545,815,1085,1335,1590,1865,2172],
 [0,275,550,815,1090,1355,1640,1910,2172],
 [0,310,565,810,1075,1330,1600,1890,2172],
]
facades=[]
for m,breaks in enumerate(BOUNDARIES):
 im=Image.open(ROOT/'source_masters'/f'master_{m}.png').convert('RGB')
 im=im.crop((0,0,im.width,660)).resize((1283,H),Image.Resampling.NEAREST)
 xs=[round(x*1283/2172) for x in breaks]
 for j,(left,right) in enumerate(zip(xs,xs[1:])):
  if right-left<50: raise ValueError((m,j,left,right))
  facades.append((m,j,im.crop((left,0,right,H))))
assert len(facades)==32
rng=random.Random(20261101)
counts=Counter()
sequence=[]
world=Image.new('RGB',(TILES*TW,H))
x=0
last=-1
while x<world.width:
 choices=[i for i in range(len(facades)) if i!=last and counts[i]<=min(counts.values() or [0])+1]
 if not choices: choices=[i for i in range(len(facades)) if i!=last]
 i=rng.choice(choices)
 m,j,art=facades[i]
 world.paste(art,(x,0))
 sequence.append({'world_x':x,'world_width':art.width,'master':m,'facade':j})
 x+=art.width;counts[i]+=1;last=i
manifest=[]
for i in range(TILES):
 im=world.crop((i*TW,0,(i+1)*TW,H))
 name=f'estafeta_{i:02d}.webp'
 im.save(OUT/name,'WEBP',quality=90,method=6)
 manifest.append({'tile':i,'filename':name,'world_start':i*TW,'sha256':hashlib.sha256((OUT/name).read_bytes()).hexdigest()})
contact=Image.new('RGB',(1920,975))
for i in range(10):
 im=Image.open(OUT/f'estafeta_{i:02d}.webp').resize((960,195))
 contact.paste(im,((i%2)*960,(i//2)*195))
contact.save(ROOT/'contact_first_ten.jpg',quality=90)
(ROOT/'manifest.json').write_text(json.dumps({'tile_width':TW,'tile_height':H,'tiles':manifest,'facade_sequence':sequence,'source_reuse_count':dict(counts),'note':'Architectural-boundary-cropped continuous source-pixel world; unverified real-world geography, motif reuse, and seams require artistic review'},indent=2),encoding='utf-8')
print('facades',len(facades),'world',world.size,'reuse minmax',min(counts.values()),max(counts.values()))
print('bytes',sum(p.stat().st_size for p in OUT.glob('*.webp')))
