#!/usr/bin/env python3
"""Local PIL geometry/parallax QA; never mislabel as Flutter capture."""
import zipfile,json,hashlib
from pathlib import Path
from PIL import Image,ImageDraw
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
SRCZIP=Path('/mnt/data/files/MIREN_Y_SARA_RC3_FIX2_PARALLAX_GITHUB_COMPLETO.zip')
OUTPUT=ROOT/'qa/visual_evidence';OUTPUT.mkdir(parents=True,exist_ok=True)
MAN=json.loads((ROOT/'qa/school_hifi_lab/SCHOOL_HIFI_MANIFEST.json').read_text())
PNGS=ROOT/'assets/images/interiors_parallax/school'
assert MAN['tile_size']==[880,278] and len(MAN['panels'])==27
assert len({p['sha256'] for p in MAN['panels']})==27
assert len({p['room'] for p in MAN['panels']})==5
for r in MAN['panels']:
 p=PNGS/f"z{r['zone']}_panel_{r['variant']}.png"
 with Image.open(p) as im:
  im.verify()
 with Image.open(p) as im:
  assert im.mode=='RGBA' and im.size==(880,278)
  a=np.asarray(im.getchannel('A'))
  assert (a[:,0:8]>250).all() and (a[:,-8:]>250).all()
 assert hashlib.sha256(p.read_bytes()).hexdigest()==r['sha256']
print('Verified exact byte hashes for 27 new RGBA tiles')
with zipfile.ZipFile(SRCZIP) as z:
 FAR=Image.open(z.open('assets/images/chapter1/ch1_parallax/montanas_ciudad_ciclo.png')).convert('RGB').crop((0,102,2200,380)).resize((2200,278))
 MID=Image.open(z.open('assets/images/chapter1/ch1_parallax/arbolado_medio_ciclo.png')).convert('RGBA').crop((0,102,2020,380)).resize((2020,278))
 FLOOR=Image.open(ROOT/'assets/images/ground/stage_6_hifi.png').convert('RGBA')

def background(camera,width=1000):
 base=Image.new('RGBA',(width,450),(147,195,226,255))
 for raw,speed in [(FAR,.30),(MID,.56)]:
  off=int(camera*speed)%raw.width
  layer=Image.new('RGBA',(width,278))
  for x in range(-off-raw.width,width,raw.width):
   layer.paste(raw,(x,0))
  # Image.paste with RGB into RGBA may lose alpha, use explicit composite.
  base.alpha_composite(layer,(0,0))
 return base

def row_scene(zone,exterior_cam=0,width=1000):
 base=background(exterior_cam,width)
 start=zone*10000
 for i in range(3):
  f=Image.open(PNGS/f'z{zone}_panel_{i}.png').convert('RGBA')
  x=i*880-450
  pasted=Image.new('RGBA',base.size,(0,0,0,0))
  pasted.paste(f,(x,0));base.alpha_composite(pasted)
 for xx in range(-FLOOR.width,width+FLOOR.width,FLOOR.width):
  p=Image.new('RGBA',base.size,(0,0,0,0));p.paste(FLOOR,(xx,278));base.alpha_composite(p)
 return base.convert('RGB')

checks=[];contact=Image.new('RGB',(1000,450*6),'white')
for z in range(3):
 before=row_scene(z,0);after=row_scene(z,550)
 a=np.asarray(before);b=np.asarray(after)
 changed=np.any(a!=b,axis=2)
 # A static ceiling/wall area must remain exactly unchanged.
 # In-place panel alpha under window => changed only there.
 alpha_mask=np.zeros((450,1000),bool)
 for i in range(3):
  f=np.asarray(Image.open(PNGS/f'z{z}_panel_{i}.png').convert('RGBA'))
  x=i*880-450
  start=max(0,x);end=min(1000,x+880)
  if end>start:
   alpha_mask[:278,start:end] |= f[:,start-x:end-x,3]<250
 a_stat=float(changed[~alpha_mask].mean()); a_win=float(changed[alpha_mask].mean())
 assert a_stat < .003,(z,a_stat)
 assert a_win > .25,(z,a_win)
 checks.append({'zone':z,'moving_window_rate':round(a_win,3),'moving_wall_rate':round(a_stat,6)})
 before.save(OUTPUT/f'zone{z}_landscape0.png')
 after.save(OUTPUT/f'zone{z}_landscape550.png')
 contact.paste(before,(0,z*900));contact.paste(after,(0,z*900+450))
contact.resize((900,2430)).save(OUTPUT/'MOVING_WINDOWS_PIL_PREVIEW.jpg',quality=90)
print('Window-only changes verified:',checks)
(OUTPUT/'PIL_PARALLAX_RESULTS.json').write_text(json.dumps(checks,indent=2))
