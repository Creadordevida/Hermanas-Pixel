#!/usr/bin/env python3
"""Actual reference-image school tiles, preserving the moving-window parallax.

Source: the art accepted in the user message, NOT the old simplified school
murals. Only corridor/classroom/PC lab/library/lockers physical assets used.
No placeholder characters. No gallery captions. Images are regenerated in
separate stage background atlas panels and never override the protected source.
"""
from __future__ import annotations
import json, math, hashlib
from pathlib import Path
from PIL import Image, ImageDraw
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/'assets/images/school_hifi/school_five_scenes_master.png'
OUTPUT=ROOT/'assets/images/interiors_parallax/school'
MANIFEST=ROOT/'qa/school_hifi_lab/SCHOOL_HIFI_MANIFEST.json'
TILE=(880,278)
# (top,bottom), keeping labels out of the detailed wall after scaling.
BANDS=((0,204),(218,405),(420,610),(624,817),(832,1006))
ROOM_NAMES=('pasillo','aula','informatica','biblioteca','taquillas')
# (x0,y0,x1,y1) inward glass only. Structural metal mullions stay in front.
GLASS=(
 ((346,32,459,120),(486,32,580,122),(717,35,818,117),(838,34,940,122),(991,31,1040,109)),
 ((380,246,478,332),(502,244,594,335),(628,243,737,336)),
 ((504,448,584,512),(596,448,673,515),(703,447,783,518),(794,448,871,516),(915,449,986,516),(994,449,1084,519)),
 ((570,647,667,730),(698,647,824,732),(862,647,971,735),(980,648,1050,733)),
 ((1078,857,1127,922),(1144,857,1187,921)),
)
# Each zone is a meaningful part of the school, not 9 barely shifted crops
# from the same art. The chapter starts in hall/lockers; transitions through
# a library and desk classroom; finishes in a PC room and study center.
ROOM_SEQUENCE=(
 (0,4,0,4,3,0,4,3,0),
 (1,1,0,1,3,1,1,0,3),
 (2,2,4,2,3,2,2,4,2),
)
# Horizontally different close-up positions within each distinct mural;
# varied to expose architecture and avoid returning the same exact crop.
VIEW_VARIANTS=(0,0.35,0.76,1.,0.56,0.17,0.94,0.43,0.68)


def sha(p:Path)->str:
    return hashlib.sha256(p.read_bytes()).hexdigest()

def tile_source(master:Image.Image, room:int, zone:int, index:int):
    y0,y1=BANDS[room]; band_h=y1-y0
    # Uniform scale: 187-204 source pixels -> exactly 278 world pixels.
    factor=TILE[1]/band_h
    srcw=int(math.ceil(TILE[0]/factor))
    available=master.width-srcw
    left=round(VIEW_VARIANTS[index]*available)
    left=max(0,min(available,left+((zone*37+index*17)%41)-20))
    bbox=(left,y0,left+srcw,y1)
    wall=master.crop(bbox).convert('RGBA')
    # Alpha is authored BEFORE resize; frame dividers stay solid because mask
    # coordinates explicitly mark only inner glass (no colour thresholds).
    alpha=np.asarray(wall.getchannel('A')).copy()
    window_count=0
    for xa,ya,xb,yb in GLASS[room]:
        x0=max(xa,left);x1=min(xb,left+srcw)
        ylo=max(ya,y0);yhi=min(yb,y1)
        if x1-x0<10 or yhi-ylo<15:continue
        alpha[ylo-y0:yhi-y0,x0-left:x1-left]=4
        window_count+=1
    wall.putalpha(Image.fromarray(alpha,'L'))
    # Proportional XY resize, never the previous 1320x480->880x278 squash.
    # LANCZOS for AI pixel illustration's deliberate antialiased edges.
    wall=wall.resize(TILE,Image.Resampling.LANCZOS)
    # A transparent architectural glass pane is layered over TWO active
    # outdoor landscape cycles by StagePainter's existing .30/.56 parallax.
    # Enforce narrow structural vertical endposts to join adjacent modules.
    d=ImageDraw.Draw(wall,'RGBA')
    for x in (0,TILE[0]-8):
        d.rectangle((x,0,x+7,TILE[1]-1),fill=(95,91,93,255))
        d.line((x+2,0,x+2,TILE[1]-1),fill=(210,188,157,255),width=1)
        d.line((x+6,0,x+6,TILE[1]-1),fill=(58,56,69,255),width=1)
    # Corrected upscale never contains reference-strip headings or sprites.
    return wall, {'room':ROOM_NAMES[room],'source_rect':list(bbox),
                  'scale':round(factor,6),'glass_panes':window_count}


def generate(root=ROOT):
    src=root/'assets/images/school_hifi/school_five_scenes_master.png'
    dst=root/'assets/images/interiors_parallax/school'
    man=root/'qa/school_hifi_lab/SCHOOL_HIFI_MANIFEST.json'
    if not src.is_file():
        raise FileNotFoundError('OBLIGATORIO: falta la imagen maestra aceptada '+str(src))
    master=Image.open(src).convert('RGBA')
    if master.size!=(1448,1086):
        raise ValueError(f'Unexpected five-room master size {master.size}')
    # The gallery labels are NOT part of the school; reconstruct the ceiling
    # with identical same-scene architectural pixels, not blurred rectangles.
    for room,(y0,y1) in enumerate(BANDS):
        width=(261,224,302,384,400)[room]
        patch=master.crop((600,y0,600+width,y0+39))
        master.paste(patch,(0,y0))
    dst.mkdir(parents=True,exist_ok=True);man.parent.mkdir(parents=True,exist_ok=True)
    records=[]
    for z,row in enumerate(ROOM_SEQUENCE):
        for n,room in enumerate(row):
            tile,info=tile_source(master,room,z,n)
            p=dst/f'z{z}_panel_{n}.png';tile.save(p,optimize=True)
            ar=np.asarray(tile.getchannel('A'))
            count=int((ar<128).sum())
            # A corridor may have no windows; verify across all 27 panels.
            if count<0: raise ValueError('Invalid alpha')
            record={'zone':z,'variant':n,**info,'size':list(tile.size),
                    'transparent_pixels':count,'sha256':sha(p)}
            records.append(record)
    m={'source':'user-supplied five-room image, characters absent',
       'master_sha256':sha(src),'stage':6,'rooms':list(ROOM_NAMES),
       'tile_size':list(TILE),'parallax_speeds':[.30,.56,1.0],
       'panel_count':len(records),'panels':records}
    man.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n')
    assert len(records)==27
    assert len(set(x['sha256'] for x in records))==27
    assert sum(x['transparent_pixels']>1000 for x in records)>=15
    print('Generated 27 school panels from EXACT supplied master; moving glass retained')
    return m

if __name__=='__main__':generate()
