#!/usr/bin/env python3
"""Remove the geometric low-poly potted plant baked into school floor tiles.

Protect original ground/stage_6.png. Make separate stage_6_hifi.png;
chapter 7 references it only when genuine five-scene school art is enabled.
"""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFilter
import hashlib,json
ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT/'assets/images/ground/stage_6.png'
DST=ROOT/'assets/images/ground/stage_6_hifi.png'
def main():
    if not SRC.exists(): raise FileNotFoundError(SRC)
    original=Image.open(SRC).convert('RGB')
    if original.size!=(540,202): raise ValueError('Wrong stage-6 floor size')
    donor=original.crop((290,0,375,63))
    clean=original.copy(); clean.paste(donor,(99,0))
    m=Image.new('L',original.size,0)
    ImageDraw.Draw(m).rectangle((99,0,184,63),fill=255)
    m=m.filter(ImageFilter.GaussianBlur(6))
    output=Image.composite(clean,original,m)
    DST.parent.mkdir(parents=True,exist_ok=True)
    output.save(DST,optimize=True)
    print('Clean floor generated from same high-resolution paving (NO polygons)')
if __name__=='__main__':main()
